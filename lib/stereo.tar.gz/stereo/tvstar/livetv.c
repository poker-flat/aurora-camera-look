/*  SETUP TARGA FOR LIVE VIDEO PLUS OVERLAY:

Setting of the TARGA board:
segemnt 0xD000   IObase 220 

TARGA set for live video and overlay enabled
Resolution 256x243 at 16 bit (For initial testing)
*/

//common declarations:
#include <conio.h>
#include <dos.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <malloc.h>
#include <\tkit\targa\include\tardev.h>

int c16bitred,c16bitgreen,c16bitblue,c16bitblk;
int c8bitwhite,c8bitgrey,c8bitblk;
int brightness=31;
int contrast=31;

#include <sys\timeb.h>


int main() {
struct _timeb timebuffer;
double start,finish;
long t1,t2;
int ms1,ms2,i;
int r,seg_val,off_val;
//  init TARGAs
// 	printf("\nTARGA init:"); getch();
	r=TV_GraphInit();
	if (r!=0){ printf("\nerror in GraphInit"); exit(0);}

//	printf("\nswitch board 0:"); getch();
	r=TV_SwitchBoard((int)0);		// set board number
	if (r!=0) {printf("/nerror in Swith to 1"); exit(0);}

 //	printf("\nset resolution 3,2,0:"); getch();
	r=TV_SetResolution(3,2,0);	//3=512x486  2=16 bit  0=interlaced
	if (r!=0) printf("\nerror in SetResolution");

	TV_PackColor(&c16bitred,31,0,0,0,0);
	TV_PackColor(&c16bitgreen,0,31,0,0,0);
	TV_PackColor(&c16bitblue,0,0,31,0,0);
	TV_PackColor(&c16bitblk,0,0,0,0,0);
	TV_Erase(&c16bitred);

// 	printf("\ncomposit video:"); getch();
	TV_SetRGBorCV(0);		//Composite video
//	printf("\nlive video:"); getch();
	TV_SetLiveMode();		//display live video

//	printf("\nset cntr/brght:"); getch();
		TV_SetContrast(contrast);
		TV_SetBrightness(brightness);

	TV_SetZoom(2,0,0);		//256x243 resolution
	set_overlaybit();
	TV_SetOverMode();		//are both statements needed?
//	set_grid(2);
	printf("\nLive TV mode with overlay + grid");

	// use precalculated shift & mask values -
	// (defines in tardef.h:  int S1,S2,M2,S3; // shift & mask values)
	printf("\n S1==rows/bank (as power of 2) = %d",S1);
	printf("\n S2==bytes/row                 = %d",S2);
	printf("\n M2==bytes/row                 = %d (%x)",M2,M2);
	printf("\n S3==bytes/pix                 = %d",S3);
	printf("\n dregB (ioBase+0x803)          = %x",dregB);
	printf("\n dregA (ioBase+0x802)          = %x",dregA);
	seg_val= _FP_SEG(DB); 
	off_val=_FP_OFF(DB);
	printf("\n DB: segment                   = %x",seg_val);
	printf("\n DB: offset                    = %x",off_val);
	seg_val= _FP_SEG(SB); 
	off_val=_FP_OFF(SB);
	printf("\n SB: segment                   = %x",seg_val);
	printf("\n SB: offset                    = %x",off_val);

	MEMORY_ENABLE;			// enable TARGA+ memory 

	set_brightness_contrast();
}

int set_grid(int zoom) {
int x,y;
if (zoom==1) {
	TV_Line(&c16bitgreen,3,256,243,509,243);
	TV_Line(&c16bitgreen,3,256,243,256,0);}
if (zoom==2) {
	TV_Line(&c16bitgreen,3,128,122,255,122);
	TV_Line(&c16bitgreen,3,128,122,128,0);}
}

int set_overlaybit(){
int x,y,overlay=0xFFFF;
//	for (y=0;y<244;y++)
//	for (x=0;x<256;x++) TV_PutPix(&overlay,x,y);
	for (y=0;y<486;y++)
	for (x=0;x<512;x++) TV_PutPix(&overlay,x,y);
}

int set_brightness_contrast() {
int oldcn,oldbr,key,ii,color;
	printf("\n\n\nAdjust TARGA digitizer using arrow keys:");
	printf("\n      left-right:   contrast");
	printf("\n      up-down:      brightness");
	printf("\nExit with Return key\n");
	

loop:	printf("\ncontrast= %2d   brightness= %2d",contrast,brightness);

	while (-!_kbhit()){}

	if ((key=getch())==0) goto ASCII;

	if (key==13) return(0);

	goto loop;

ASCII:	key=getch();

// up/down: brightness
	if (key==72) {if (brightness<63) brightness++;}
	if (key==80) {if (brightness>0) brightness--;}

// left/right: contrast
	if (key==77) {if (contrast<63) contrast++;}
	if (key==75) {if (contrast>1) contrast--;}

digitize:
//	grab_image(jstat);
		TV_SetContrast(contrast);
		TV_SetBrightness(brightness);
//		TV_SetLiveMode();
//		TV_GrabFrame();
//		TV_SetDispMode();
	goto loop;

}
