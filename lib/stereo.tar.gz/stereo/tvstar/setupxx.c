/*  SETUP TARGA FOR LIVE VIDEO PLUS OVERLAY:

Setting of the TARGA board:
segemnt 0xD000   IObase 220 

TARGA set for live video and overlay enabled
Resolution 256x243 at 16 bit
*/

#include <graph.h>
#include <conio.h>
#include <dos.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <bios.h>
#include <malloc.h>
#include <\tkit\targa\include\tardev.h>


far main()
{
int key,i,ii,j,cswitcher,ierr,oldsec,dnr;
/*
unsigned int c16bitred=0x7C00;
unsigned int c16bitgreen=0x03E0;
unsigned int c16bitblue=0x001F;
unsigned int c16bitblk=0x0000;
unsigned char c8bitwhite=0xff;
unsigned char c8bitgrey=0x7F;
unsigned char c8bitblk=0x00;
*/

//  init TARGAs
	if ((r=TV_GraphInit())) { printf("/nerror in GraphInit"); err=1; }

// TARGA (board 0)
	if ((r=TV_SwitchBoard(0))) { printf("/nerror in Swith to 0"); err=1; }
	r=TV_SetResolution(3,2,0);	//3=512x486  2=16 bit  0=interlaced 
	if (r!=0) printf("\nerror in SetResolution")
	TV_SetZoom(2,0,0);		//256x243 resolution
	TV_SetRGBorCV(0);		//composite video
	TV_SetLiveMode();		//display the video input
	TV_SetOverMode();		//allow overlay
	MEMORY_ENABLE;			// enable TARGA+ memory 

end_program:
//	TV_GraphEnd();
//	_setvideomode(_TEXTC80);
//	exit(0);
}
