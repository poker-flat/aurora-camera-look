// works 8 dec 94

#include <dos.h   >
#include <conio.h >
#include <stdio.h >
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <\tkit\targa\include\tardev.h>
/*
	#define FAR     _far
	#define PASCAL  _pascal

//#include "tardev.h"
//#define iobase 0x220
#define dreg0 0x220
#define dreg1 0x221
#define dreg2 0x222
#define dreg3 0x223
#define dreg4 0x620
#define dreg5 0x621
#define dreg6 0x622
#define dreg7 0x623
#define dreg8 0xA20
#define dreg9 0xA21
#define dregA 0xA22
#define dregB 0xA23
#define dregC 0xE20
#define dregD 0xE21
#define dregE 0xE22
#define dregF 0xE23

#define IN_IR(r,v) outp(dreg5,r);v = inpw(dregE)
#define OUT_IR(r,v) outp(dreg5,r);outpw(dregE,v)
 
#define MEMORY_ENABLE  outp(dregC,inp(dreg6) | 0x01)
#define MEMORY_DISABLE outp(dregC,inp(dreg6) & 0xfe)
*/

/* 
Prototypes
*/
int  FAR PASCAL _loadds TV_GraphInit      (void);
int  FAR PASCAL _loadds TV_SwitchBoard    (int );

void FAR PASCAL _loadds TV_SetTARGAOverlay(int );
int  FAR PASCAL _loadds TV_SetVGAOverlay  (int );
void FAR PASCAL _loadds TV_ReadEEPROM     (int far *);                                         
void FAR PASCAL _loadds TV_WriteDAC       (int,int,int,int far *);
void FAR PASCAL _loadds TV_WritePLL       (int far *);

int  FAR PASCAL _loadds TV_GetResolution  (void);
int  FAR PASCAL _loadds TV_SetResolution  (int,int,int);
int  FAR PASCAL _loadds TV_SetInterlace   (int );

void FAR PASCAL _loadds TV_SetDispMode    (void);                                         
void FAR PASCAL _loadds TV_SetBLiveMode   (void);
void FAR PASCAL _loadds TV_SetOverMode    (void);
void FAR PASCAL _loadds TV_SetLiveMode    (void);
int  FAR PASCAL _loadds TV_SetZoom        (int,int,int);                               
int  FAR PASCAL _loadds TV_GetZoom        (void);
int  FAR PASCAL _loadds TV_SetPan         (int,int);
void FAR PASCAL _loadds TV_SetRGBorCV     (int );
void FAR PASCAL _loadds TV_SetSVideo      (int );
void FAR PASCAL _loadds TV_SetGenLock     (int );
void FAR PASCAL _loadds TV_SetVCRorCamera (int );
void FAR PASCAL _loadds TV_GrabFrame      (void);
void FAR PASCAL _loadds TV_GrabField      (int );
int  FAR PASCAL _loadds TV_GetField       (void); 
int  FAR PASCAL _loadds TV_GetVidLoss     (void);
void FAR PASCAL _loadds TV_SetGrab        (int );
void FAR PASCAL _loadds TV_VWait          (void);
void FAR PASCAL _loadds TV_SetBorderColor (long far *);
void FAR PASCAL _loadds TV_SetContrast    (int );
void FAR PASCAL _loadds TV_SetSaturation  (int );
void FAR PASCAL _loadds TV_SetHue         (int );
void FAR PASCAL _loadds TV_SetBrightness  (int );
void FAR PASCAL _loadds TV_SetLUTMode     (int );
void FAR PASCAL _loadds TV_SetGamma       (double);
void FAR PASCAL _loadds TV_PutLUTs        (unsigned char far *,int,int);
void FAR PASCAL _loadds TV_GetLUTs        (unsigned char far *,int,int);

int  FAR PASCAL _loadds TV_SetBlndMode      (int,int);
int  FAR PASCAL _loadds TV_SetOverlayCapture( int);
int  FAR PASCAL _loadds TV_OverlayCapture   (void);
void FAR PASCAL _loadds TV_Chromakey        (int );
void FAR PASCAL _loadds TV_SetLiveMixGain   (int );
void FAR PASCAL _loadds TV_SetLiveMixZero   (int );
int  FAR PASCAL _loadds TV_ChromaCapture    (void);
int  FAR PASCAL _loadds TV_SetLivePort      (int);
int  FAR PASCAL _loadds TV_SetBufferPort    (int);
void FAR PASCAL _loadds TV_SetNotOVLLevel   (int);
void FAR PASCAL _loadds TV_SetOVLLevel      (int);
int  FAR PASCAL _loadds TV_ShowPage         (int);
int  FAR PASCAL _loadds TV_GrabPage         (int);

void FAR PASCAL _loadds TV_SetMask    (int );
void FAR PASCAL _loadds TV_Rectangle  (void far *,int,int,int,int,int);
void FAR PASCAL _loadds TV_Curve      (void far *,int,int,int,int,int,int,int,int,int,int);
void FAR PASCAL _loadds TV_Line       (void far *,int,int,int,int,int);
void FAR PASCAL _loadds TV_Ellipse    (void far *,int,int,int,int);
void FAR PASCAL _loadds TV_Erase      (void far *); 
void FAR PASCAL _loadds TV_FillRect   (void far *,int,int,int,int);
void FAR PASCAL _loadds TV_CopyRect   (int,int,int,int,int,int);
void FAR PASCAL _loadds TV_GetRow     (int,int,int);
void FAR PASCAL _loadds TV_PutRow     (int,int,int);
void FAR PASCAL _loadds TV_GetPix     (void far *,int,int);
void FAR PASCAL _loadds TV_PutPix     (void far *,int,int);
char far * FAR PASCAL _loadds TV_GetSrcAddress(int,int);
char far * FAR PASCAL _loadds TV_GetDstAddress(int,int);
void FAR PASCAL _loadds TV_PackColor  (void far *,int,int,int,int,int);
void FAR PASCAL _loadds TV_UnpackColor(void far *,int far *,int far *,int far *,int far *,int far *);

int  FAR PASCAL _loadds TV_PutPic     (char far *,int,int,int,int);
int  FAR PASCAL _loadds TV_GetPic     (char far *,int,int);

void FAR PASCAL _loadds TV_Text(void far *,int,int,int,int,int,char far *,int,int);

void FAR PASCAL _loadds TV_GraphEnd   (void);


void FAR PASCAL _loadds VWait          (void);
void FAR PASCAL _loadds SetDispMode    (void);                                         
void FAR PASCAL _loadds SetOverMode    (void);
void FAR PASCAL _loadds SetLiveMode    (void);
void FAR PASCAL _loadds SetRGBorCV     (int );
void FAR PASCAL _loadds SetGenLock     (int );
void FAR PASCAL _loadds SetVCRorCamera (int );

/*
 SetDispMode - Memory Mode.
*/
void FAR PASCAL _loadds SetDispMode(void) {
	VWait();
	outp(dregD,inp (dregD) & 0x8f        );
}

/*
 Memory enable
*/
void FAR PASCAL _loadds Enable_Memory(void) {
	outp(dregC,inp(dreg6) | 0x01);
}

/*
 Memory disable
*/
void FAR PASCAL _loadds Disable_Memory(void) {
	outp(dregC,inp(dreg6) & 0xfe);
}

/*
VWait - Wait for vertical blanking.
*/
void FAR PASCAL _loadds VWait(void) {
	int i;
	
	outp(dreg5,0x53);  i = inpw(dregE);
	i=0; while(!i) { outp(dreg5,0x53);  i = inpw(dregE); }
	i=1; while( i) { outp(dreg5,0x53);  i = inpw(dregE); }
}

/*
SetOverMode - Overlay Mode.
*/
void FAR PASCAL _loadds SetOverMode(void) {
	VWait();
	outp(dregD,(inp(dregD) & 0x8f) | 0xa0);
}

/*
SetLiveMode - Live Mode.
*/
void FAR PASCAL _loadds SetLiveMode(void) {
	VWait();
	outp(dregD,(inp(dregD) & 0x8f) | 0xb0);
}

/*
SetRGBorCV - RGB or CV input.

	j==1 RGB input
	j==0 Composite Video input
*/
void FAR PASCAL _loadds SetRGBorCV(int j) {
	int     i;

	outp(dreg5,0xe4);  i = inpw(dregE);
	outp(dreg4,(i & 0xbf) | ((j & 0x01) << 6));
	outp(dreg5,0xe6);  outpw(dregE,0x7f);
}

/*
SetGenLock - genlock.

i==1 genlock on
i==0 genlock off
*/
void FAR PASCAL _loadds SetGenLock(int i)  {
	if(i==0) { outp(dregD,inp(dregD) & 0x7f); }
	else     { outp(dregD,inp(dregD) | 0x80); }
}

/*
SetVCRorCamera - camera or VCR.

i==0 camera or broadcast source vpm=1
i==1 VCR    or Videodisk        vpm=0
*/
void FAR PASCAL _loadds SetVCRorCamera(int i) {
	outp(dreg5,0x21);  outpw(dregE,(i==0));
//	OUT_IR(0x21,(i==0));                        // GENCTRL bit 0
}

/*
GetVidLoss - Get ls  (VIDSTAT bit 1).

Return: 0 sync present
		1 sync NOT present
*/

int FAR PASCAL _loadds GetVidLoss(void) {
	inp(dreg0);                                 // read twice
	return(inp(dreg0) & 0x02) >> 1;
}

int main() {
/* test of routines
	void FAR PASCAL _loadds SetDispMode(void) {
	void FAR PASCAL _loadds Enable_Memory(void) {
	void FAR PASCAL _loadds Disable_Memory(void) {
	void FAR PASCAL _loadds VWait(void) {
void FAR PASCAL _loadds SetOverMode(void) {
	void FAR PASCAL _loadds SetLiveMode(void) {
void FAR PASCAL _loadds SetRGBorCV(int j) {
	void FAR PASCAL _loadds SetGenLock(int i)  {
void FAR PASCAL _loadds SetVCRorCamera(int i) {
	int FAR PASCAL _loadds GetVidLoss(void) {
*/
int c16bitred,c16bitgreen,c16bitblue,c16bitblk;
int r,x,y;

// set up for test
	r=TV_GraphInit();
	if (r!=0){ printf("\nerror in GraphInit"); exit(0);}
//	printf("\nswitch board 0:"); getch();
	r=TV_SwitchBoard((int)0);		// set board number
	if (r!=0) {printf("/nerror in Swith to 1"); exit(0);}
 //	printf("\nset resolution 3,2,0:"); getch();
	r=TV_SetResolution(3,2,0);	//3=512x486  2=16 bit  0=interlaced
	if (r!=0) printf("\nerror in SetResolution");
	TV_SetZoom(2,0,0);		//256x243 resolution
//	set_overlaybit();
// overlay only in 16 bit mode
//	TV_SetOverMode();		//are both statements needed?
//	set_grid(2);
//	printf("\nLive TV mode with overlay + grid");

	TV_PackColor(&c16bitred,31,0,0,0,0);
	TV_PackColor(&c16bitgreen,0,31,0,0,0);
	TV_PackColor(&c16bitblue,0,0,31,0,0);
	TV_PackColor(&c16bitblk,0,0,0,0,0);


	printf("\nMemory enable. Paint screen blue with line.."); getch();
	TV_Erase(&c16bitblue);
	Enable_Memory();
	for (x=0; x<256; x++) PutASCPix(0,x,x);
	printf("\nMemory Disable. Try to Paint line on blue.."); getch();
	TV_Erase(&c16bitblue);
	Disable_Memory();
	for (x=0; x<256; x++) PutASCPix(0,x,x);
	printf("\nMemory enable. Paint screen green with line.."); getch();
	TV_Erase(&c16bitgreen);
	Enable_Memory();
	for (x=0; x<256; x++) PutASCPix(0,x,x);

	printf("\ngo live.."); getch();
	SetLiveMode();
	printf("\ndisp memory.."); getch();
	SetDispMode();
	printf("\ngo live.."); getch();
	SetLiveMode();
	printf("\ndisp memory.."); getch();
	SetDispMode();
	printf("\ngo live.."); getch();
	SetLiveMode();

	printf("\nset genlock=0.."); getch();
	SetGenLock(0);
	printf("\nset genlock=1.."); getch();
	SetGenLock(1);
	printf("\nset genlock=0.."); getch();
	SetGenLock(0);
	printf("\nset genlock=1.."); getch();
	SetGenLock(1);

	printf("\nGet video loss.."); getch();
	printf("\n videoloss= %d",GetVidLoss());
	printf("\nGet video loss.."); getch();
	printf("\n videoloss= %d",GetVidLoss());
	printf("\nGet video loss.."); getch();
	printf("\n videoloss= %d",GetVidLoss());

}

int hBnkASC=0xffff;

int PutASCPix(unsigned int c,int x,int y) {
int far *d;
register int i;
//	MEMORY_ENABLE;
	i=y>>5; if(i!=hBnkASC) { outp(0x0A23,i); hBnkASC=i; }
	d = (int far *)(0xD8000000L+((((long)y<<9)&0x3FFF)+x<<1)); 
	*(int far *)d = c;
}
/*
int PutmapPix(int c,int x,int y) {
	int far *d;
	register int i;
	i=y>>5; if(i!=hBnkmap) { outp(0x0A33,i); hBnkmap=i; }
	d = (int far *)(0xD8000000L+((((long)y<<9)&0x3FFF)+x<<1)); 
	*(int  far *)d = c;
}
*/

int set_overlaybit(){
int x,y,overlay=0xFFFF;
//	for (y=0;y<244;y++)
//	for (x=0;x<256;x++) TV_PutPix(&overlay,x,y);
	for (y=0;y<486;y++)
	for (x=0;x<512;x++) TV_PutPix(&overlay,x,y);
}
