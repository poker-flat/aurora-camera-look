// works without TV_library

#include <dos.h   >
#include <conio.h >
#include <stdio.h >
#include <string.h>
#include <stdlib.h>
#include <math.h>
//#include <\tkit\targa\include\tardev.h>
/* 
Prototypes
*/
void _far _pascal _loadds VWait          (void);
void _far _pascal _loadds SetDispMode    (void);                                         
void _far _pascal _loadds SetOverMode    (void);
void _far _pascal _loadds SetLiveMode    (void);
void _far _pascal _loadds SetRGBorCV     (int );
void _far _pascal _loadds SetGenLock     (int );
void _far _pascal _loadds SetVCRorCamera (int );
void _far _pascal _loadds Enable_Memory  (void);
void _far _pascal _loadds Disable_Memory (void);
int _far _pascal _loadds GetVidLoss      (void);


int main() {
/* test of routines
	void FAR PASCAL _loadds SetDispMode(void) {
	void FAR PASCAL _loadds Enable_Memory(void) {
	void FAR PASCAL _loadds Disable_Memory(void) {
	void FAR PASCAL _loadds VWait(void) {
void FAR PASCAL _loadds SetOverMode(void) {
	void FAR PASCAL _loadds SetLiveMode(void) {
void FAR PASCAL _loadds SetRGBorCV(int j) {
	void FAR PASCAL _loadds SetGenLock(int i)  {
void FAR PASCAL _loadds SetVCRorCamera(int i) {
	int FAR PASCAL _loadds GetVidLoss(void) {
*/
int c16bitred,c16bitgreen,c16bitblue,c16bitblk;
int r,x,y;

// set up for test ALL TV_library refs removed
/*
	r=TV_GraphInit();
	if (r!=0){ printf("\nerror in GraphInit"); exit(0);}
//	printf("\nswitch board 0:"); getch();
	r=TV_SwitchBoard((int)0);		// set board number
	if (r!=0) {printf("/nerror in Swith to 1"); exit(0);}
 //	printf("\nset resolution 3,2,0:"); getch();
	r=TV_SetResolution(3,2,0);	//3=512x486  2=16 bit  0=interlaced
	if (r!=0) printf("\nerror in SetResolution");
	TV_SetZoom(2,0,0);		//256x243 resolution
//	set_overlaybit();
// overlay only in 16 bit mode
//	TV_SetOverMode();		//are both statements needed?
//	set_grid(2);
//	printf("\nLive TV mode with overlay + grid");

	TV_PackColor(&c16bitred,31,0,0,0,0);
	TV_PackColor(&c16bitgreen,0,31,0,0,0);
	TV_PackColor(&c16bitblue,0,0,31,0,0);
	TV_PackColor(&c16bitblk,0,0,0,0,0);
*/

	c16bitred=31*32*32;
	c16bitgreen=31*32;
	c16bitblue=31;
	c16bitblk=0;


	printf("\nMemory enable. Paint screen blue with line.."); getch();
	Enable_Memory();
	Erase_ASC(c16bitblue);
	for (x=0; x<256; x++) PutASCPix(0,x,x);
	printf("\nMemory Disable. Try to Paint line on blue.."); getch();
	Erase_ASC(c16bitblue);
	Disable_Memory();
	for (x=0; x<256; x++) PutASCPix(0,x,x);
	printf("\nMemory enable. Paint screen green with line.."); getch();
	Enable_Memory();
	Erase_ASC(c16bitgreen);
	for (x=0; x<256; x++) PutASCPix(0,x,x);

	printf("\ngo live.."); getch();
	SetLiveMode();
	printf("\ndisp memory.."); getch();
	SetDispMode();
	printf("\ngo live.."); getch();
	SetLiveMode();
	printf("\ndisp memory.."); getch();
	SetDispMode();
	printf("\ngo live.."); getch();
	SetLiveMode();

	printf("\nset genlock=0.."); getch();
	SetGenLock(0);
	printf("\nset genlock=1.."); getch();
	SetGenLock(1);
	printf("\nset genlock=0.."); getch();
	SetGenLock(0);
	printf("\nset genlock=1.."); getch();
	SetGenLock(1);

	printf("\nGet video loss.."); getch();
	printf("\n videoloss= %d",GetVidLoss());
	printf("\nGet video loss.."); getch();
	printf("\n videoloss= %d",GetVidLoss());
	printf("\nGet video loss.."); getch();
	printf("\n videoloss= %d",GetVidLoss());

}

int hBnkASC=0xffff;

int PutASCPix(unsigned int c,int x,int y) {
int far *d;
register int i;
//	MEMORY_ENABLE;
	i=y>>5; if(i!=hBnkASC) { outp(0x0A23,i); hBnkASC=i; }
	d = (int far *)(0xD8000000L+((((long)y<<9)&0x3FFF)+x<<1)); 
	*(int far *)d = c;
}
/*
int PutmapPix(int c,int x,int y) {
	int far *d;
	register int i;
	i=y>>5; if(i!=hBnkmap) { outp(0x0A33,i); hBnkmap=i; }
	d = (int far *)(0xD8000000L+((((long)y<<9)&0x3FFF)+x<<1)); 
	*(int  far *)d = c;
}
*/

int set_overlaybit(){
int x,y,overlay=0xFFFF;
//	for (y=0;y<244;y++)
//	for (x=0;x<256;x++) TV_PutPix(&overlay,x,y);
//	for (y=0;y<486;y++)
//	for (x=0;x<512;x++) TV_PutPix(&overlay,x,y);
}

int Erase_ASC(int color){
int x,y;
	for (y=0;y<244;y++)
	for (x=0;x<256;x++) PutASCPix(color,x,y);
}
