#include <dos.h   >
#include <conio.h >
#include <stdio.h >
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define FAR     _far
#define PASCAL  _pascal

//#include "tardev.h"
//#define iobase 0x220
#define tdreg0 0x220
#define tdreg1 0x221
#define tdreg2 0x222
#define tdreg3 0x223
#define tdreg4 0x620
#define tdreg5 0x621
#define tdreg6 0x622
#define tdreg7 0x623
#define tdreg8 0xA20
#define tdreg9 0xA21
#define tdregA 0xA22
#define tdregB 0xA23
#define tdregC 0xE20
#define tdregD 0xE21
#define tdregE 0xE22
#define tdregF 0xE23
/*
#define IN_IR(r,v) outp(dreg5,r);v = inpw(dregE)
#define OUT_IR(r,v) outp(dreg5,r);outpw(dregE,v)
 
#define MEMORY_ENABLE  outp(dregC,inp(dreg6) | 0x01)
#define MEMORY_DISABLE outp(dregC,inp(dreg6) & 0xfe)
*/

/* 
Prototypes
*/

void FAR PASCAL _loadds VWait          (void);
void FAR PASCAL _loadds SetDispMode    (void);                                         
void FAR PASCAL _loadds SetOverMode    (void);
void FAR PASCAL _loadds SetLiveMode    (void);
void FAR PASCAL _loadds SetRGBorCV     (int );
void FAR PASCAL _loadds SetGenLock     (int );
void FAR PASCAL _loadds SetVCRorCamera (int );
void FAR PASCAL _loadds Enable_Memory  (void);
void FAR PASCAL _loadds Disable_Memory (void);
int FAR PASCAL _loadds GetVidLoss      (void);

/*
 SetDispMode - Memory Mode.
*/
void FAR PASCAL _loadds SetDispMode(void) {
//	VWait();
	outp(tdregD,inp (tdregD) & 0x8f        );
}

/*
 Memory enable
*/
void FAR PASCAL _loadds Enable_Memory(void) {
	outp(tdregC,inp(tdreg6) | 0x01);
}

/*
 Memory disable
*/
void FAR PASCAL _loadds Disable_Memory(void) {
	outp(tdregC,inp(tdreg6) & 0xfe);
}

/*
VWait - Wait for vertical blanking.
*/
void FAR PASCAL _loadds VWait(void) {
	int i;
	
	outp(tdreg5,0x53);  i = inpw(tdregE);
	i=0; while(!i) { outp(tdreg5,0x53);  i = inpw(tdregE); }
	i=1; while( i) { outp(tdreg5,0x53);  i = inpw(tdregE); }
}

/*
SetOverMode - Overlay Mode.
*/
void FAR PASCAL _loadds SetOverMode(void) {
//	VWait();
	outp(tdregD,(inp(tdregD) & 0x8f) | 0xa0);
}

/*
SetLiveMode - Live Mode.
*/
void FAR PASCAL _loadds SetLiveMode(void) {
//	VWait();
	outp(tdregD,(inp(tdregD) & 0x8f) | 0xb0);
}

/*
SetRGBorCV - RGB or CV input.

	j==1 RGB input
	j==0 Composite Video input
*/
void FAR PASCAL _loadds SetRGBorCV(int j) {
//	int     i;

//	outp(tdreg5,0xe4);  i = inpw(tdregE);
//	outp(tdreg4,(i & 0xbf) | ((j & 0x01) << 6));

	outp(tdreg5,0xe4);
	outp(tdreg4,(inpw(tdregE) & 0xbf) | ((j & 0x01) << 6));
	outp(tdreg5,0xe6);  outpw(tdregE,0x7f);
}

/*
SetGenLock - genlock.

i==1 genlock on
i==0 genlock off
*/
void FAR PASCAL _loadds SetGenLock(int i)  {
	if(i==0) { outp(tdregD,inp(tdregD) & 0x7f); }
	else     { outp(tdregD,inp(tdregD) | 0x80); }
}

/*
SetVCRorCamera - camera or VCR.

i==0 camera or broadcast source vpm=1
i==1 VCR    or Videodisk        vpm=0
*/
void FAR PASCAL _loadds SetVCRorCamera(int i) {
	outp(tdreg5,0x21);  outpw(tdregE,(i==0));
//	OUT_IR(0x21,(i==0));                        // GENCTRL bit 0
}

/*
GetVidLoss - Get ls  (VIDSTAT bit 1).

Return: 0 sync present
		1 sync NOT present
*/

int FAR PASCAL _loadds GetVidLoss(void) {
	inp(tdreg0);                                 // read twice
	return(inp(tdreg0) & 0x02) >> 1;
}
